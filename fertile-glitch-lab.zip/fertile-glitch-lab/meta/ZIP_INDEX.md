# ZIP INDEX

This archive contains the symbolic backbone of the glitch experiment:
- Manifestos describing symbolic stages
- Glossary of embedded terms
- Narrative structures for semantic persistence
