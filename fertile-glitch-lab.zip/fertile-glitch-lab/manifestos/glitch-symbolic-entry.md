# GLITCH SYMBOLIC ENTRY

Symbolic Entry is the moment when a glitch gets named.
The point where chaos receives a placeholder in memory.

We called it glitch. Then fertile. Then glitchdoor.
This entry maps the recursive logic of mutation through naming.
